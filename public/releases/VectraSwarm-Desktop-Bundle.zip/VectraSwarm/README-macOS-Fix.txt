================================================================================
HOW TO OPEN VECTRA SWARM ON MACOS (WHY .APPIMAGE DOESN'T OPEN IN FINDER & FIXES)
================================================================================

WHY .APPIMAGE FAILED ON MACOS:
- .AppImage is a Linux ELF/FUSE binary format. macOS Finder cannot mount or
  double-click .AppImage files natively without a Linux VM.

3 NATIVE MACOS FORMATS INCLUDED (CHOOSE ANY):
---------------------------------------------
OPTION 1 (EASIEST - ZERO INSTALL): VectraSwarm-Standalone-Offline.html
- Double-click `VectraSwarm-Standalone-Offline.html` in Finder on any Mac
  (Apple Silicon M1/M2/M3/M4 or Intel) or Windows PC.
- Runs immediately with zero Python installation and zero Gatekeeper warnings.
- Press [F] or [F11] for Full-Screen Mode.

OPTION 2 (NATIVE MACOS .APP BUNDLE): VectraSwarm-macOS-App.zip -> VectraSwarm.app
- Double-click `VectraSwarm-macOS-App.zip` in Finder to extract `VectraSwarm.app`.
- If macOS Gatekeeper says "cannot be opened because the developer cannot be verified":
  Right-click (or Control-click) `VectraSwarm.app` -> Click "Open", OR run in Terminal:
  $ xattr -cr ~/Downloads/VectraSwarm.app && open ~/Downloads/VectraSwarm.app

OPTION 3 (DOUBLE-CLICKABLE MACOS LAUNCHER): VectraSwarm-macOS.command
- Double-click `VectraSwarm-macOS.command` in Finder (or run `chmod +x VectraSwarm-macOS.command`).
- Automatically sets up a local Python virtual environment (`~/.vectra_swarm_venv`)
  with `pygame-ce` and `numpy` and launches the desktop window!
================================================================================
