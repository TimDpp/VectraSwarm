#!/usr/bin/env python3
"""
Vectra Swarm: Infinite Wave Arena (Pygame + NumPy Desktop Edition)
Complete implementation featuring:
- Infinite map with modular coordinate grid & sector beacons
- NumPy vectorized SoA entity physics, distance-matrix collisions & XP gem magnetization
- 1 initial power-up at round start; 3 random power-ups on every Level-Up
- Upgrading owned power-ups increases level & effectiveness stats
- Difficulty curve scaling per wave + new enemy archetype every 5th wave
- Full-screen toggle (F / F11), customizable keyboard controls (key rebinding),
  volume settings, and WCAG High-Contrast accessibility mode.
"""

import json
import math
import os
import sys

try:
    import numpy as np
    import pygame
except ImportError:
    print("Installing required desktop dependencies (pygame, numpy)...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame-ce", "numpy"])
    import numpy as np
    import pygame

from engine_numpy import VectorizedArenaEngine, POWER_UP_DEFS, FIFTH_WAVE_ENEMY_NAMES

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".vectra_swarm_settings.json")

DEFAULT_SETTINGS = {
    "master_volume": 80,
    "sfx_volume": 85,
    "music_volume": 60,
    "muted": False,
    "high_contrast": False,
    "fullscreen": False,
    "keybindings": {
        "up": pygame.K_w,
        "down": pygame.K_s,
        "left": pygame.K_a,
        "right": pygame.K_d,
        "dash": pygame.K_SPACE,
        "fullscreen": pygame.K_f,
        "pause": pygame.K_ESCAPE,
    },
}


def load_settings() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                merged = {**DEFAULT_SETTINGS, **data}
                merged["keybindings"] = {**DEFAULT_SETTINGS["keybindings"], **data.get("keybindings", {})}
                return merged
        except Exception:
            pass
    return json.loads(json.dumps(DEFAULT_SETTINGS))


def save_settings(settings: dict) -> None:
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2)
    except Exception:
        pass


def make_beep_sound(freq: float, duration_ms: int, volume: float) -> "pygame.mixer.Sound":
    sample_rate = 44100
    n_samples = int(sample_rate * (duration_ms / 1000.0))
    t = np.linspace(0, duration_ms / 1000.0, n_samples, endpoint=False)
    envelope = np.exp(-t * 18.0)
    wave = (np.sin(2.0 * np.pi * freq * t) * envelope * 32767 * volume).astype(np.int16)
    stereo = np.column_stack((wave, wave))
    return pygame.sndarray.make_sound(stereo)


def run_game() -> None:
    pygame.init()
    try:
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
        audio_ok = True
    except Exception:
        audio_ok = False

    settings = load_settings()
    flags = pygame.FULLSCREEN if settings["fullscreen"] else pygame.RESIZABLE
    screen = pygame.display.set_mode((1280, 760), flags)
    pygame.display.set_caption("Vectra Swarm: Infinite Wave Arena")
    clock = pygame.time.Clock()

    font_xl = pygame.font.SysFont("bahnschrift", 48, bold=True)
    font_lg = pygame.font.SysFont("bahnschrift", 30, bold=True)
    font_md = pygame.font.SysFont("bahnschrift", 20, bold=True)
    font_sm = pygame.font.SysFont("consolas", 15)

    engine = VectorizedArenaEngine()
    state = "MENU"  # MENU, PLAYING, LEVEL_UP, PAUSED, SETTINGS, GAME_OVER
    rebind_action = None
    current_choices = []
    starter_options = ["pulse_cannon", "orbital_blades", "chain_arc"]
    starter_idx = 0
    wave_timer = 0.0
    spawn_timer = 0.0
    dash_cd = 0.0
    fire_cd = 0.0
    banner_text = ""
    banner_timer = 0.0

    def play_tone(freq: float, dur: int = 75) -> None:
        if not audio_ok or settings.get("muted"):
            return
        vol = (settings["master_volume"] / 100.0) * (settings["sfx_volume"] / 100.0) * 0.35
        if vol > 0.01:
            try:
                snd = make_beep_sound(freq, dur, vol)
                snd.play()
            except Exception:
                pass

    def spawn_wave_enemies(wave_num: int, count: int = 8) -> None:
        free_slots = np.flatnonzero(~engine.enemy_active)
        actual = min(count, free_slots.size)
        if actual <= 0:
            return
        angles = np.random.uniform(0, 2 * np.pi, size=actual).astype(np.float32)
        dists = np.random.uniform(460, 640, size=actual).astype(np.float32)
        slots = free_slots[:actual]
        engine.enemy_pos[slots, 0] = engine.player_pos[0] + np.cos(angles) * dists
        engine.enemy_pos[slots, 1] = engine.player_pos[1] + np.sin(angles) * dists

        max_type = min(6, 2 + (wave_num // 5))
        types = np.random.randint(0, max_type + 1, size=actual, dtype=np.int32)
        if wave_num % 5 == 0 and actual > 0:
            types[0] = max_type  # Guarantee 5th-wave challenger archetype
        engine.enemy_type[slots] = types
        hp_mult = 1.0 + (wave_num - 1) * 0.22
        base_hps = np.array([28, 24, 46, 85, 210, 165, 480], dtype=np.float32)[types] * hp_mult
        engine.enemy_hp[slots] = base_hps
        engine.enemy_max_hp[slots] = base_hps
        engine.enemy_radius[slots] = np.array([13, 14, 17, 18, 25, 20, 32], dtype=np.float32)[types]
        engine.enemy_speed[slots] = np.array([112, 92, 96, 128, 68, 105, 58], dtype=np.float32)[types] * (
            1.0 + min(0.85, (wave_num - 1) * 0.035)
        )
        engine.enemy_active[slots] = True

    running = True
    while running:
        dt = min(clock.tick(60) / 1000.0, 0.05)
        w, h = screen.get_size()
        hc = settings["high_contrast"]

        bg_col = (0, 0, 0) if hc else (9, 13, 22)
        fg_col = (255, 255, 255) if hc else (248, 250, 252)
        accent_col = (255, 255, 0) if hc else (56, 189, 248)
        card_col = (12, 12, 12) if hc else (15, 23, 42)
        border_col = (255, 255, 0) if hc else (51, 65, 85)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if rebind_action:
                    settings["keybindings"][rebind_action] = event.key
                    save_settings(settings)
                    rebind_action = None
                    play_tone(660, 60)
                    continue

                kb = settings["keybindings"]
                if event.key == kb["fullscreen"] or event.key == pygame.K_F11:
                    settings["fullscreen"] = not settings["fullscreen"]
                    save_settings(settings)
                    flags = pygame.FULLSCREEN if settings["fullscreen"] else pygame.RESIZABLE
                    screen = pygame.display.set_mode((1280, 760), flags)

                if state == "MENU":
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        engine = VectorizedArenaEngine()
                        engine.inventory = {starter_options[starter_idx]: 1}
                        spawn_wave_enemies(1, 8)
                        wave_timer = 0.0
                        state = "PLAYING"
                        play_tone(520, 90)
                    elif event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        starter_idx = event.key - pygame.K_1
                        play_tone(440, 50)
                    elif event.key == pygame.K_s:
                        state = "SETTINGS"
                elif state == "SETTINGS":
                    if event.key == pygame.K_ESCAPE:
                        state = "MENU"
                    elif event.key == pygame.K_c:
                        settings["high_contrast"] = not settings["high_contrast"]
                        save_settings(settings)
                    elif event.key == pygame.K_m:
                        settings["muted"] = not settings["muted"]
                        save_settings(settings)
                    elif event.key == pygame.K_UP:
                        settings["master_volume"] = min(100, settings["master_volume"] + 10)
                        save_settings(settings)
                    elif event.key == pygame.K_DOWN:
                        settings["master_volume"] = max(0, settings["master_volume"] - 10)
                        save_settings(settings)
                    elif event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5):
                        actions = ["up", "down", "left", "right", "dash"]
                        rebind_action = actions[event.key - pygame.K_1]
                elif state == "PLAYING":
                    if event.key == kb["pause"]:
                        state = "PAUSED"
                    elif event.key == kb["dash"] and dash_cd <= 0.0:
                        dash_cd = 1.3
                        play_tone(320, 80)
                elif state == "PAUSED":
                    if event.key == kb["pause"] or event.key == pygame.K_RETURN:
                        state = "PLAYING"
                    elif event.key == pygame.K_s:
                        state = "SETTINGS"
                    elif event.key == pygame.K_q:
                        state = "MENU"
                elif state == "LEVEL_UP":
                    if event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        idx = event.key - pygame.K_1
                        if idx < len(current_choices):
                            engine.apply_upgrade(current_choices[idx].power_id)
                            play_tone(780, 110)
                            state = "PLAYING"
                elif state == "GAME_OVER":
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        engine = VectorizedArenaEngine()
                        engine.inventory = {starter_options[starter_idx]: 1}
                        spawn_wave_enemies(1, 8)
                        state = "PLAYING"
                    elif event.key == pygame.K_ESCAPE:
                        state = "MENU"

        screen.fill(bg_col)

        # Simulation Update
        if state == "PLAYING":
            keys = pygame.key.get_pressed()
            kb = settings["keybindings"]
            move = np.array(
                [
                    float(keys[kb["right"]] or keys[pygame.K_RIGHT]) - float(keys[kb["left"]] or keys[pygame.K_LEFT]),
                    float(keys[kb["down"]] or keys[pygame.K_DOWN]) - float(keys[kb["up"]] or keys[pygame.K_UP]),
                ],
                dtype=np.float32,
            )
            norm = float(np.linalg.norm(move))
            dash_cd = max(0.0, dash_cd - dt)
            if norm > 0:
                speed_lvl = engine.inventory.get("kinetic_thrusters", 0)
                dash_mult = 2.4 if dash_cd > 1.1 else 1.0
                spd = 240.0 * (1.0 + speed_lvl * 0.11) * dash_mult
                engine.player_pos += (move / norm) * spd * dt

            # Auto-fire nearest enemy
            fire_cd -= dt
            active_e = np.flatnonzero(engine.enemy_active)
            if fire_cd <= 0.0 and active_e.size > 0:
                pulse_lvl = max(1, engine.inventory.get("pulse_cannon", 1))
                fire_cd = max(0.14, 0.36 * (0.89 ** (pulse_lvl - 1)))
                deltas = engine.enemy_pos[active_e] - engine.player_pos
                d2 = np.sum(deltas * deltas, axis=1)
                nearest = active_e[int(np.argmin(d2))]
                vec = engine.enemy_pos[nearest] - engine.player_pos
                vlen = float(np.linalg.norm(vec)) + 1e-6
                free_p = np.flatnonzero(~engine.proj_active)
                if free_p.size > 0:
                    pi = free_p[0]
                    engine.proj_pos[pi] = engine.player_pos.copy()
                    engine.proj_vel[pi] = (vec / vlen) * 560.0
                    engine.proj_dmg[pi] = 24.0 * (1.0 + (pulse_lvl - 1) * 0.28)
                    engine.proj_ttl[pi] = 1.0
                    engine.proj_active[pi] = True
                    play_tone(480, 40)

            wave_timer += dt
            spawn_timer += dt
            if spawn_timer >= max(0.25, 1.2 * (0.92 ** (engine.wave - 1))):
                spawn_timer = 0.0
                spawn_wave_enemies(engine.wave, 2)

            if wave_timer >= 20.0:
                wave_timer = 0.0
                engine.wave += 1
                spawn_wave_enemies(engine.wave, 6 + engine.wave)
                if engine.wave % 5 == 0:
                    challenger = FIFTH_WAVE_ENEMY_NAMES.get(engine.wave, f"Ascendant Tier Mk.{engine.wave // 5}")
                    banner_text = f"WAVE {engine.wave} CHALLENGER UNLOCKED: {challenger}"
                    banner_timer = 4.5
                    play_tone(310, 160)

            kills, leveled = engine.step_simulation(dt)
            if leveled:
                current_choices = engine.roll_three_upgrades()
                play_tone(880, 140)
                state = "LEVEL_UP"

        # Render Infinite Grid
        cam_x = float(engine.player_pos[0]) - w / 2.0
        cam_y = float(engine.player_pos[1]) - h / 2.0
        grid_step = 96
        g_col = (70, 70, 70) if hc else (22, 32, 50)
        for gx in range(int(-cam_x % grid_step), w, grid_step):
            pygame.draw.line(screen, g_col, (gx, 0), (gx, h), 2 if hc else 1)
        for gy in range(int(-cam_y % grid_step), h, grid_step):
            pygame.draw.line(screen, g_col, (0, gy), (w, gy), 2 if hc else 1)

        # Render XP Gems
        for gi in np.flatnonzero(engine.gem_active):
            gx = int(engine.gem_pos[gi, 0] - cam_x)
            gy = int(engine.gem_pos[gi, 1] - cam_y)
            pygame.draw.rect(screen, (0, 255, 102) if hc else (52, 211, 153), (gx - 4, gy - 4, 8, 8))

        # Render Active Enemies
        for ei in np.flatnonzero(engine.enemy_active):
            ex = int(engine.enemy_pos[ei, 0] - cam_x)
            ey = int(engine.enemy_pos[ei, 1] - cam_y)
            r = int(engine.enemy_radius[ei])
            col = (255, 51, 102) if hc else (244, 63, 94)
            pygame.draw.circle(screen, col, (ex, ey), r)
            if hc:
                pygame.draw.circle(screen, (255, 255, 255), (ex, ey), r, 2)

        # Render Projectiles
        for pi in np.flatnonzero(engine.proj_active):
            px = int(engine.proj_pos[pi, 0] - cam_x)
            py = int(engine.proj_pos[pi, 1] - cam_y)
            pygame.draw.circle(screen, accent_col, (px, py), 5)

        # Render Player
        pygame.draw.circle(screen, accent_col, (w // 2, h // 2), 16)
        pygame.draw.circle(screen, (255, 255, 255), (w // 2, h // 2), 16, 2)

        # Render HUD
        hud_str = (
            f"HP {int(engine.player_hp)}/{int(engine.player_max_hp)}   "
            f"WAVE {engine.wave}   LVL {engine.level} (XP {int(engine.xp)}/{int(engine.xp_next)})   "
            f"SCORE {engine.score}"
        )
        screen.blit(font_md.render(hud_str, True, fg_col), (24, 20))

        if banner_timer > 0:
            banner_timer -= dt
            b_surf = font_md.render(banner_text, True, (255, 255, 0))
            screen.blit(b_surf, (w // 2 - b_surf.get_width() // 2, 64))

        # Overlay Screens
        if state == "MENU":
            overlay = pygame.Surface((w, h), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 210))
            screen.blit(overlay, (0, 0))
            t_surf = font_xl.render("VECTRA SWARM // PYGAME + NUMPY", True, accent_col)
            screen.blit(t_surf, (80, 120))
            screen.blit(
                font_md.render(
                    "Starter Power-Up (Press 1/2/3): " + POWER_UP_DEFS[starter_options[starter_idx]][0],
                    True,
                    fg_col,
                ),
                (80, 210),
            )
            screen.blit(font_lg.render("[ENTER] Start Run   [S] Settings, High-Contrast & Keybinds", True, fg_col), (80, 280))
            screen.blit(
                font_sm.render("Controls: WASD/Arrows Move | Space Dash | F/F11 Fullscreen | Esc Pause", True, fg_col),
                (80, h - 60),
            )
        elif state == "SETTINGS":
            overlay = pygame.Surface((w, h), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 230))
            screen.blit(overlay, (0, 0))
            screen.blit(font_lg.render("SETTINGS, HIGH-CONTRAST & KEY REBINDING", True, accent_col), (80, 80))
            screen.blit(
                font_md.render(
                    f"[C] High-Contrast Mode: {'ON (WCAG AAA)' if hc else 'STANDARD'}   "
                    f"[UP/DOWN] Master Volume: {settings['master_volume']}%   [M] Mute: {settings['muted']}",
                    True,
                    fg_col,
                ),
                (80, 150),
            )
            kb = settings["keybindings"]
            binds_text = (
                f"Press [1-5] to Rebind -> [1] Up: {pygame.key.name(kb['up'])}  "
                f"[2] Down: {pygame.key.name(kb['down'])}  [3] Left: {pygame.key.name(kb['left'])}  "
                f"[4] Right: {pygame.key.name(kb['right'])}  [5] Dash: {pygame.key.name(kb['dash'])}"
            )
            screen.blit(font_sm.render(binds_text, True, fg_col), (80, 220))
            if rebind_action:
                screen.blit(
                    font_md.render(f"PRESS ANY KEY TO REBIND '{rebind_action.upper()}'...", True, (255, 255, 0)),
                    (80, 270),
                )
            screen.blit(font_md.render("Press [ESC] to Return to Main Menu", True, fg_col), (80, 340))
        elif state == "LEVEL_UP":
            overlay = pygame.Surface((w, h), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 215))
            screen.blit(overlay, (0, 0))
            screen.blit(
                font_lg.render(f"LEVEL {engine.level} REACHED - CHOOSE 1 OF 3 UPGRADES (PRESS 1, 2, OR 3)", True, accent_col),
                (80, 100),
            )
            for idx, ch in enumerate(current_choices):
                rect = pygame.Rect(80 + idx * 360, 180, 330, 240)
                pygame.draw.rect(screen, card_col, rect, border_radius=8)
                pygame.draw.rect(screen, border_col, rect, 2, border_radius=8)
                tag = f"UPGRADE LV.{ch.current_level} -> LV.{ch.next_level}" if ch.is_upgrade else "NEW POWER-UP LV.1"
                screen.blit(font_sm.render(f"[{idx + 1}] {tag}", True, accent_col), (rect.x + 16, rect.y + 20))
                screen.blit(font_md.render(ch.name, True, fg_col), (rect.x + 16, rect.y + 60))
                screen.blit(font_sm.render(ch.description[:38], True, fg_col), (rect.x + 16, rect.y + 110))

        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    run_game()
